/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package form;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Locale;
import javax.swing.JFrame;
import javax.swing.Timer;
import javax. swing. *;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
/**
 *
 * @author admin
 */
public class tampilanAwal extends javax.swing.JFrame {

    /**
     * Creates new form tampilanAwal
     */
    
   Connection con = null;
   ResultSet rs = null;
   Statement statement = null;
   
   void updateTableauto() throws SQLException{
       rs = statement.executeQuery("select * from data_barang");
       Tdatabarang.setModel(DbUtils.resultSetToTableModel(rs));
   }
   
   void updateTableautoDS() throws SQLException{
       rs = statement.executeQuery("select * from data_supplier");
       DStable.setModel(DbUtils.resultSetToTableModel(rs));
   }
   
    void updateTableautoPB() throws SQLException{
       rs = statement.executeQuery("select * from penjualan_barang");
       PBTable.setModel(DbUtils.resultSetToTableModel(rs));
   }
    
    void updateTableautobel() throws SQLException{
       rs = statement.executeQuery("select * from pembelian_barang");
       beltable.setModel(DbUtils.resultSetToTableModel(rs));
   }
   
   void kosong(){
       
//       tfDBKodeBarang.setText("");
       jDateChooser1.setDate(null);
       tfDBNamaBarang.setText("");
       tfDBHarga.setText("");
       tfDBPcs.setText("");
       tfDBKodeBarang.requestFocus();
   }
   
   void buttonfalse(){
       belclear.setEnabled(false);
       belsimpan.setEnabled(false);
       beledit.setEnabled(false);
       belhapus.setEnabled(false);
       PBedit.setEnabled(false);
       PBsimpan.setEnabled(false);
       PBclear.setEnabled(false);
       PBhapus.setEnabled(false);
       DBhapus.setEnabled(false);
       DSclear.setEnabled(false);
       DSEdit.setEnabled(false);
       DSHapus.setEnabled(false);
       DSSimpan.setEnabled(false);
       DBedit.setEnabled(false);
       DBhapus.setEnabled(false);
       DBsimpan.setEnabled(false);
       DBclear.setEnabled(false);
   }
   
   void buttonfalsebeforeselect(){
       
     
       beledit.setEnabled(false);
       belhapus.setEnabled(false);
       PBedit.setEnabled(false);
      
  
       PBhapus.setEnabled(false);
       DBhapus.setEnabled(false);
     
       DSEdit.setEnabled(false);
       DSHapus.setEnabled(false);
      
       DBedit.setEnabled(false);
       DBhapus.setEnabled(false);
     
   }
   
  public void buttontrue(){
       belclear.setEnabled(true);
       belsimpan.setEnabled(true);
       beledit.setEnabled(true);
       belhapus.setEnabled(true);
       PBedit.setEnabled(true);
       PBsimpan.setEnabled(true);
       PBclear.setEnabled(true);
       PBhapus.setEnabled(true);
       DBhapus.setEnabled(true);
       DSclear.setEnabled(true);
       DSEdit.setEnabled(true);
       DSHapus.setEnabled(true);
       DSSimpan.setEnabled(true);
       DBedit.setEnabled(true);
       DBhapus.setEnabled(true);
       DBsimpan.setEnabled(true);
       DBclear.setEnabled(true);
   }
   
   void DSkosong(){
    DSnama.setText("");
    DStanggal.setDate(null);
    DSalamat.setText("");
    DSnotlpn.setText("");
    DSemail.setText("");
    DSProduk.setText("");
    DSRiwayat.setText("");
    DSPembayaran.setText("");
   }
   
   void PBkosong(){
    PBtanggaltransaksi.setDate(null);
    PBhargasatuan.setText("");
    PBjumlahbeli.setText("");
    PBtotalbayar.setText("");  
    PBkembalian.setText("");  
   }
   
   void belkosong(){
    beltanggal.setDate(null);
    belnamasupplier.setText("");
    belalamatsupplier.setText("");
    belkontak.setText("");
    belkue.setText("");
    belharga.setText("");
    belmetode.setText("");
    beldetail.setText("");   
   }
   
   
    private void userLogin(){
    lbluserlogin.setText(userSession.getUserLogin());
    }
    
    private void hakakses() {
    String user=lbluserlogin.getText();
        if(user.equals("admin")){
       
        jDataBarang.setEnabled(true);
        jDataSupplier.setEnabled(true);
        jPembelianBarang.setEnabled(true);
        jTransaksi.setEnabled(true);
        jLaporanTransaksi.setEnabled(true);
        }
        else {
        
        jDataBarang.setEnabled(true);
        jDataSupplier.setEnabled(true);
        jPembelianBarang.setEnabled(true);
        jTransaksi.setEnabled(true);
        jLaporanTransaksi.setEnabled(false);
        }
        }
    
public tampilanAwal() throws SQLException {
        initComponents();
//        buttonfalse();
//buttonfalsebeforeselect();
kode_barang_otomatis();
//userLogin();
//hakakses();
        listed();
        listedDS();
        listedPB();
        listedbel();
        
      con = koneksi.koneksiDb();
      statement = con.createStatement();
        setExtendedState(JFrame.MAXIMIZED_HORIZ);
        setVisible(true);
        setResizable(false);
        jDashboard.setBackground(new Color(204,204,255));
        jDataBarang.setBackground(new Color(204,204,255));
        jDataSupplier.setBackground(new Color(204,204,255));
        jPembelianBarang.setBackground(new Color(204,204,255));
        jTransaksi.setBackground(new Color(204,204,255));
        jLaporanTransaksi.setBackground(new Color(204,204,255));
        jDataPelanggan.setBackground(new Color(204,204,255));
        jExit.setBackground(new Color(204,204,255));
        setTanggal();
        Tampil_Jam();
        listed();

    }
    
    
    public void setTanggal(){
java.util.Date skrg = new java.util.Date();
java.text.SimpleDateFormat kal = new
java.text.SimpleDateFormat("dd-MM-yyyy");
tanggal.setText(kal.format(skrg));
}
    
   public void Tampil_Jam(){
        ActionListener taskPerformer = new ActionListener() {
 
        @Override
            public void actionPerformed(ActionEvent evt) {
            String nol_jam = "", nol_menit = "",nol_detik = "";
 
            java.util.Date dateTime = new java.util.Date();
            int nilai_jam = dateTime.getHours();
            int nilai_menit = dateTime.getMinutes();
            int nilai_detik = dateTime.getSeconds();
 
            if(nilai_jam <= 9) nol_jam= "0";
            if(nilai_menit <= 9) nol_menit= "0";
            if(nilai_detik <= 9) nol_detik= "0";
 
            String jam = nol_jam + Integer.toString(nilai_jam);
            String menit = nol_menit + Integer.toString(nilai_menit);
            String detik = nol_detik + Integer.toString(nilai_detik);
 
            ljam.setText(jam+":"+menit+":"+detik+"");
            }
        };
    new Timer(1000, taskPerformer).start();
    }   
 
   public void listed()
    {
        DefaultTableModel table = new DefaultTableModel();
        
        table.addColumn("Kode Barang");
        table.addColumn("Tanggal");
        table.addColumn("Nama Barang");
        table.addColumn("Harga");
        table.addColumn("Pcs");
        
        try
        {
            Connection kon = koneksi.koneksiDb();
            String sql = "SELECT * FROM `data_barang`";
            Statement S = kon.createStatement();
            ResultSet R = S.executeQuery(sql);
            
            while(R.next())
            {
                table.addRow(new Object[]{
                    R.getString(1),
                    R.getString(2),
                    R.getString(3),
                    R.getString(4),                
                    R.getString(5),
                });
            }
            Tdatabarang.setModel(table);
        }
        catch(Exception e){
    
}
    }
   
   public void listedDS()
    {
        DefaultTableModel table = new DefaultTableModel();
        table.addColumn("Id");
        table.addColumn("Nama");
        table.addColumn("Tgl Supply");
        table.addColumn("Alamat");
        table.addColumn("No Tlp");
        table.addColumn("Email");
        table.addColumn("Produk");
        table.addColumn("Riwayat Pembelian");
        table.addColumn("Pembayaran");
        
        try
        {
            Connection kon = koneksi.koneksiDb();
            String sql = "SELECT * FROM `data_supplier`";
            Statement S = kon.createStatement();
            ResultSet R = S.executeQuery(sql);
            
            while(R.next())
            {
                table.addRow(new Object[]{
                    R.getString(1),
                    R.getString(2),
                    R.getString(3),
                    R.getString(4),                
                    R.getString(5),
                    R.getString(6),
                    R.getString(7),
                    R.getString(8),
                    R.getString(9)
                });
            }
            DStable.setModel(table);
        }
        catch(Exception e){
    
}
    }
   
   public void listedPB()
    {
        DefaultTableModel table = new DefaultTableModel();
        table.addColumn("Kode");
        table.addColumn("Nama");
        table.addColumn("Tgl");
        table.addColumn("Nama Kue");
        table.addColumn("Jumlah");
        table.addColumn("Harga");
        table.addColumn("Metode Pembayaran");
        table.addColumn("Total Pembayaran");
        
        try
        {
            Connection kon = koneksi.koneksiDb();
            String sql = "SELECT * FROM `penjualan_barang`";
            Statement S = kon.createStatement();
            ResultSet R = S.executeQuery(sql);
            
            while(R.next())
            {
                table.addRow(new Object[]{
                    R.getString(1),
                    R.getString(2),
                    R.getString(3),
                    R.getString(4),                
                    R.getString(5),
                    R.getString(6),
                    R.getString(7),
                    R.getString(8),                
                });
            }
            PBTable.setModel(table);
        }
        catch(Exception e){
    
}
    }
   
   public void listedbel()
    {
        DefaultTableModel table = new DefaultTableModel();
        table.addColumn("Id");
        table.addColumn("Tgl Supply");
        table.addColumn("Nama Supplier");
        table.addColumn("Alamat");
        table.addColumn("No Kontak");
        table.addColumn("Kue");
        table.addColumn("Harga");
        table.addColumn("Metode");
        table.addColumn("Pengiriman");
        try
        {
            Connection kon = koneksi.koneksiDb();
            String sql = "SELECT * FROM `pembelian_barang`";
            Statement S = kon.createStatement();
            ResultSet R = S.executeQuery(sql);
            
            while(R.next())
            {
                table.addRow(new Object[]{
                    R.getString(1),
                    R.getString(2),
                    R.getString(3),
                    R.getString(4),                
                    R.getString(5),
                    R.getString(6),
                    R.getString(7),
                    R.getString(8),
                    R.getString(9),
                });
            }
            beltable.setModel(table);
        }
        catch(Exception e){
    
}
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        Jam = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tanggal = new javax.swing.JLabel();
        ljam = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jDashboard = new javax.swing.JButton();
        jDataBarang = new javax.swing.JButton();
        jDataSupplier = new javax.swing.JButton();
        jPembelianBarang = new javax.swing.JButton();
        jTransaksi = new javax.swing.JButton();
        jLaporanTransaksi = new javax.swing.JButton();
        btentang = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jExit = new javax.swing.JButton();
        jDataPelanggan = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        pnldashboard = new javax.swing.JLabel();
        pnlpembelianbarang = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        belalamatsupplier = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        belnamasupplier = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        belkontak = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        belkue = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        belharga = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        belmetode = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        beldetail = new javax.swing.JTextField();
        belsearch = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        beltable = new javax.swing.JTable();
        belclear = new javax.swing.JButton();
        belsimpan = new javax.swing.JButton();
        beledit = new javax.swing.JButton();
        belhapus = new javax.swing.JButton();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        beltanggal = new com.toedter.calendar.JDateChooser();
        pnlpenjualanbarang = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        PBTable = new javax.swing.JTable();
        PBsearch = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        PBtanggaltransaksi = new com.toedter.calendar.JDateChooser();
        PBjumlahbeli = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        PBhargasatuan = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        PBtotalbayar = new javax.swing.JTextField();
        PBclear = new javax.swing.JButton();
        PBsimpan = new javax.swing.JButton();
        PBedit = new javax.swing.JButton();
        PBhapus = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        PBkembalian = new javax.swing.JTextField();
        CBkodebarang = new javax.swing.JComboBox<>();
        CBmetodepembayaran = new javax.swing.JComboBox<>();
        pnldatasupplier = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        DSnama = new javax.swing.JTextField();
        DSalamat = new javax.swing.JTextField();
        DSnotlpn = new javax.swing.JTextField();
        DSemail = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        DStable = new javax.swing.JTable();
        DStanggal = new com.toedter.calendar.JDateChooser();
        tfDSSearch = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        DSclear = new javax.swing.JButton();
        DSEdit = new javax.swing.JButton();
        DSSimpan = new javax.swing.JButton();
        DSHapus = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        DSProduk = new javax.swing.JTextField();
        DSRiwayat = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        DSPembayaran = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        pnldatabarang = new javax.swing.JPanel();
        ldatabarang = new javax.swing.JLabel();
        DBsimpan = new javax.swing.JButton();
        DBedit = new javax.swing.JButton();
        DBhapus = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tdatabarang = new javax.swing.JTable();
        tfDBNamaBarang = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tfDBHarga = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tfDBPcs = new javax.swing.JTextField();
        tfSearch = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tfDBKodeBarang = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        DBclear = new javax.swing.JButton();
        pnllaporantransaksi = new javax.swing.JPanel();
        pnldatapelanggan = new javax.swing.JPanel();
        lbluserlogin = new javax.swing.JLabel();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 0));

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        Jam.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 51, 204));
        jLabel1.setText("Toko Kue Siska");

        tanggal.setBackground(new java.awt.Color(255, 255, 255));
        tanggal.setForeground(new java.awt.Color(255, 51, 204));
        tanggal.setText("tanggal");
        tanggal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tanggalKeyPressed(evt);
            }
        });

        ljam.setForeground(new java.awt.Color(255, 51, 204));
        ljam.setText("jam");

        javax.swing.GroupLayout JamLayout = new javax.swing.GroupLayout(Jam);
        Jam.setLayout(JamLayout);
        JamLayout.setHorizontalGroup(
            JamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JamLayout.createSequentialGroup()
                .addContainerGap(197, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(149, 149, 149)
                .addGroup(JamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tanggal)
                    .addComponent(ljam))
                .addGap(44, 44, 44))
        );
        JamLayout.setVerticalGroup(
            JamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JamLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(JamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(JamLayout.createSequentialGroup()
                        .addComponent(ljam)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tanggal)))
                .addGap(15, 15, 15))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black));
        jPanel1.setMaximumSize(new java.awt.Dimension(527, 527));

        jDashboard.setBackground(new java.awt.Color(255, 255, 255));
        jDashboard.setForeground(new java.awt.Color(255, 153, 153));
        jDashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/Continuous Mode.png"))); // NOI18N
        jDashboard.setText("Dashboard");
        jDashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDashboardActionPerformed(evt);
            }
        });

        jDataBarang.setForeground(new java.awt.Color(255, 153, 153));
        jDataBarang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/Checklist.png"))); // NOI18N
        jDataBarang.setText("Data Barang");
        jDataBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDataBarangActionPerformed(evt);
            }
        });

        jDataSupplier.setForeground(new java.awt.Color(255, 153, 153));
        jDataSupplier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/Mind Map.png"))); // NOI18N
        jDataSupplier.setText("Data Supplier");
        jDataSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDataSupplierActionPerformed(evt);
            }
        });

        jPembelianBarang.setForeground(new java.awt.Color(255, 153, 153));
        jPembelianBarang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/Finance Portal.png"))); // NOI18N
        jPembelianBarang.setText("Pembelian\nBarang");
        jPembelianBarang.setToolTipText("");
        jPembelianBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPembelianBarangActionPerformed(evt);
            }
        });

        jTransaksi.setForeground(new java.awt.Color(255, 153, 153));
        jTransaksi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/Login.png"))); // NOI18N
        jTransaksi.setText("Transaksi");
        jTransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTransaksiActionPerformed(evt);
            }
        });

        jLaporanTransaksi.setForeground(new java.awt.Color(255, 153, 153));
        jLaporanTransaksi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/data user.png"))); // NOI18N
        jLaporanTransaksi.setText("Laporan Transaksi");
        jLaporanTransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLaporanTransaksiActionPerformed(evt);
            }
        });

        btentang.setForeground(new java.awt.Color(255, 153, 153));
        btentang.setText("! Tentang");
        btentang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btentangActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/Kawaii Cupcake.png"))); // NOI18N

        jExit.setForeground(new java.awt.Color(255, 153, 153));
        jExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/Save as.png"))); // NOI18N
        jExit.setText("Exit");
        jExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jExitActionPerformed(evt);
            }
        });

        jDataPelanggan.setForeground(new java.awt.Color(255, 153, 153));
        jDataPelanggan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/data pelanggann.png"))); // NOI18N
        jDataPelanggan.setText("Data Pelanggan");
        jDataPelanggan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDataPelangganActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(btentang, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel2))
                    .addComponent(jDataBarang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jDataSupplier, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPembelianBarang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTransaksi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLaporanTransaksi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jExit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jDataPelanggan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btentang)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDataBarang, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDataSupplier, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPembelianBarang, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLaporanTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDataPelanggan, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jExit, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(82, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(247, 211, 223));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black));
        jPanel3.setLayout(new java.awt.CardLayout());

        pnldashboard.setBackground(new java.awt.Color(255, 204, 204));
        pnldashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/backpink.png"))); // NOI18N
        jPanel3.add(pnldashboard, "card2");

        pnlpembelianbarang.setBackground(new java.awt.Color(255, 51, 102));

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 3, 14)); // NOI18N
        jLabel6.setText("Pembelian Barang");

        jLabel21.setText("Nama Supplier");

        belalamatsupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belalamatsupplierActionPerformed(evt);
            }
        });

        jLabel22.setText("Alamat Supplier");

        belnamasupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belnamasupplierActionPerformed(evt);
            }
        });

        jLabel23.setText("Nomor Kontak");

        belkontak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belkontakActionPerformed(evt);
            }
        });

        jLabel24.setText("Kue DiBeli");

        belkue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belkueActionPerformed(evt);
            }
        });

        jLabel25.setText("Harga");

        belharga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belhargaActionPerformed(evt);
            }
        });

        jLabel26.setText("Metode Pembayaran");

        belmetode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belmetodeActionPerformed(evt);
            }
        });

        jLabel27.setText("Pcs");

        beldetail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beldetailActionPerformed(evt);
            }
        });

        belsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belsearchActionPerformed(evt);
            }
        });
        belsearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                belsearchKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                belsearchKeyPressed(evt);
            }
        });

        beltable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Tgl Supply", "Nama Supplier", "Alamat", "No Kontak", "Kue", "Harga", "Metode", "Pengiriman"
            }
        ));
        beltable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                beltableMouseClicked(evt);
            }
        });
        beltable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                beltableKeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(beltable);

        belclear.setText("clear");
        belclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belclearActionPerformed(evt);
            }
        });

        belsimpan.setText("simpan");
        belsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belsimpanActionPerformed(evt);
            }
        });

        beledit.setText("edit");
        beledit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beleditActionPerformed(evt);
            }
        });

        belhapus.setText("hapus");
        belhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belhapusActionPerformed(evt);
            }
        });

        jLabel37.setText("Tanggal Supply");

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/search.png"))); // NOI18N

        javax.swing.GroupLayout pnlpembelianbarangLayout = new javax.swing.GroupLayout(pnlpembelianbarang);
        pnlpembelianbarang.setLayout(pnlpembelianbarangLayout);
        pnlpembelianbarangLayout.setHorizontalGroup(
            pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlpembelianbarangLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(pnlpembelianbarangLayout.createSequentialGroup()
                            .addComponent(beledit)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(belhapus, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pnlpembelianbarangLayout.createSequentialGroup()
                            .addComponent(belclear)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(belsimpan)))
                    .addComponent(jLabel21)
                    .addComponent(belalamatsupplier, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23)
                    .addComponent(belkontak, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(jLabel37)
                    .addComponent(beldetail, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25)
                    .addComponent(belharga, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26)
                    .addComponent(belmetode, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27)
                    .addComponent(jLabel24)
                    .addComponent(belkue, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(beltanggal, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(belnamasupplier, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlpembelianbarangLayout.createSequentialGroup()
                        .addGap(211, 211, 211)
                        .addComponent(jLabel6)
                        .addGap(57, 57, 57)
                        .addComponent(jLabel38)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(belsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlpembelianbarangLayout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 667, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        pnlpembelianbarangLayout.setVerticalGroup(
            pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlpembelianbarangLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlpembelianbarangLayout.createSequentialGroup()
                        .addComponent(jLabel37)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(beltanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(belnamasupplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(belalamatsupplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(belkontak, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel24)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(belkue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(belharga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(belmetode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(beldetail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(belclear)
                            .addComponent(belsimpan))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(beledit)
                            .addComponent(belhapus)))
                    .addGroup(pnlpembelianbarangLayout.createSequentialGroup()
                        .addGroup(pnlpembelianbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlpembelianbarangLayout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addComponent(belsearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel6)
                            .addComponent(jLabel38))
                        .addGap(30, 30, 30)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(147, Short.MAX_VALUE))
        );

        jPanel3.add(pnlpembelianbarang, "card5");

        pnlpenjualanbarang.setBackground(new java.awt.Color(153, 255, 255));

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel7.setText("Transaksi");

        PBTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode", "Nama", "Tgl", "Nama Kue", "Jumlah", "Harga", "Metode Pembayaran", "Total Bayar"
            }
        ));
        PBTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PBTableMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(PBTable);

        PBsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PBsearchActionPerformed(evt);
            }
        });
        PBsearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PBsearchKeyPressed(evt);
            }
        });

        jLabel29.setText("Tanggal Transaksi");

        jLabel31.setText("Jumlah Pembelian");

        jLabel32.setText("Harga Satuan");

        PBhargasatuan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PBhargasatuanActionPerformed(evt);
            }
        });

        jLabel33.setText("Metode Pembayaran");

        jLabel34.setText("Total Bayar");

        PBclear.setText("Clear");
        PBclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PBclearActionPerformed(evt);
            }
        });

        PBsimpan.setText("Bayar");
        PBsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PBsimpanActionPerformed(evt);
            }
        });

        PBedit.setText("Edit");
        PBedit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PBeditMouseClicked(evt);
            }
        });
        PBedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PBeditActionPerformed(evt);
            }
        });

        PBhapus.setText("Hapus");
        PBhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PBhapusActionPerformed(evt);
            }
        });

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/search.png"))); // NOI18N

        jLabel36.setText("Kode Barang");

        jLabel39.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel39.setText("Kembalian");

        CBkodebarang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        CBmetodepembayaran.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout pnlpenjualanbarangLayout = new javax.swing.GroupLayout(pnlpenjualanbarang);
        pnlpenjualanbarang.setLayout(pnlpenjualanbarangLayout);
        pnlpenjualanbarangLayout.setHorizontalGroup(
            pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                        .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                                .addGap(8, 357, Short.MAX_VALUE)
                                .addComponent(jLabel7)
                                .addGap(103, 103, 103))
                            .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                                .addComponent(jLabel36)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(PBsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                        .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PBkembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                                .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                    .addComponent(PBedit)
                                    .addComponent(PBclear)
                                    .addComponent(jLabel39))
                                .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                                        .addGap(13, 13, 13)
                                        .addComponent(PBhapus))
                                    .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(PBsimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(CBkodebarang, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel29)
                                    .addComponent(PBtotalbayar, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                                        .addGap(4, 4, 4)
                                        .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel33)
                                            .addComponent(PBtanggaltransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel32)
                                            .addComponent(PBjumlahbeli, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel31)
                                            .addComponent(PBhargasatuan, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel34))))
                                .addComponent(CBmetodepembayaran, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 619, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22))
        );
        pnlpenjualanbarangLayout.setVerticalGroup(
            pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(PBsearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlpenjualanbarangLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel36)))
                .addGap(8, 8, 8)
                .addComponent(CBkodebarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlpenjualanbarangLayout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PBtanggaltransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel33)
                        .addGap(5, 5, 5)
                        .addComponent(CBmetodepembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PBjumlahbeli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PBhargasatuan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PBtotalbayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel39)
                        .addGap(2, 2, 2)
                        .addComponent(PBkembalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PBsimpan)
                            .addComponent(PBclear))
                        .addGap(8, 8, 8)
                        .addGroup(pnlpenjualanbarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PBhapus)
                            .addComponent(PBedit)))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(106, Short.MAX_VALUE))
        );

        jPanel3.add(pnlpenjualanbarang, "card6");

        pnldatasupplier.setBackground(new java.awt.Color(204, 255, 204));

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel5.setText("Data Supplier");

        jLabel12.setText("Nama");

        jLabel13.setText("Tanggal Awal Supply");

        jLabel14.setText("Alamat");

        jLabel15.setText("No Tlp");

        jLabel16.setText("Email");

        DSnama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DSnamaActionPerformed(evt);
            }
        });

        DStable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nama", "Tgl Supply", "Alamat", "No Tlp", "Email", "Produk", "Riwayat Pembelian", "Pembayaran"
            }
        ));
        DStable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DStableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(DStable);

        tfDSSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfDSSearchKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfDSSearchKeyPressed(evt);
            }
        });

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/search.png"))); // NOI18N

        DSclear.setText("clear");
        DSclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DSclearActionPerformed(evt);
            }
        });

        DSEdit.setText("edit");
        DSEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DSEditActionPerformed(evt);
            }
        });

        DSSimpan.setText("simpan");
        DSSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DSSimpanActionPerformed(evt);
            }
        });

        DSHapus.setText("hapus");
        DSHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DSHapusActionPerformed(evt);
            }
        });

        jLabel18.setText("Produk");

        jLabel19.setText("Riwayat Pembelian");

        jLabel20.setText("Pembayaran");

        javax.swing.GroupLayout pnldatasupplierLayout = new javax.swing.GroupLayout(pnldatasupplier);
        pnldatasupplier.setLayout(pnldatasupplierLayout);
        pnldatasupplierLayout.setHorizontalGroup(
            pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnldatasupplierLayout.createSequentialGroup()
                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnldatasupplierLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addGroup(pnldatasupplierLayout.createSequentialGroup()
                                .addComponent(DSclear)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(DSSimpan))
                            .addGroup(pnldatasupplierLayout.createSequentialGroup()
                                .addComponent(DSEdit)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(DSHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnldatasupplierLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel16)
                                    .addComponent(DSalamat)
                                    .addComponent(DSnotlpn)
                                    .addComponent(DSemail, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel18)
                                    .addComponent(DSProduk, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(DSRiwayat, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19))
                                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel12)
                                    .addComponent(DSnama)
                                    .addComponent(DStanggal, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE))
                                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(DSPembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20))))
                        .addGap(18, 18, 18)))
                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnldatasupplierLayout.createSequentialGroup()
                        .addGap(178, 178, 178)
                        .addComponent(jLabel5)
                        .addGap(56, 56, 56)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfDSSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pnldatasupplierLayout.setVerticalGroup(
            pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnldatasupplierLayout.createSequentialGroup()
                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnldatasupplierLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(tfDSSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnldatasupplierLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnldatasupplierLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnldatasupplierLayout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(DSnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(DStanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel5))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnldatasupplierLayout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DSalamat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DSnotlpn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DSemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DSProduk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DSRiwayat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DSPembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DSclear)
                            .addComponent(DSSimpan))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnldatasupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DSEdit)
                            .addComponent(DSHapus))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnldatasupplierLayout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(17, 17, 17))))
        );

        jPanel3.add(pnldatasupplier, "card4");

        pnldatabarang.setBackground(new java.awt.Color(255, 255, 204));

        ldatabarang.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        ldatabarang.setText("Data Barang");

        DBsimpan.setText("Simpan");
        DBsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DBsimpanActionPerformed(evt);
            }
        });

        DBedit.setText("Edit");
        DBedit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DBeditMouseClicked(evt);
            }
        });
        DBedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DBeditActionPerformed(evt);
            }
        });

        DBhapus.setText("Hapus");
        DBhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DBhapusActionPerformed(evt);
            }
        });

        Tdatabarang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode Barang", "Tanggal", "Nama Barang", "Harga", "Pcs"
            }
        ));
        Tdatabarang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TdatabarangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Tdatabarang);

        jLabel3.setText("Nama Barang");

        jLabel4.setText("Harga");

        tfDBHarga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfDBHargaKeyTyped(evt);
            }
        });

        jLabel8.setText("Pcs");

        tfDBPcs.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfDBPcsKeyTyped(evt);
            }
        });

        tfSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfSearchActionPerformed(evt);
            }
        });
        tfSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfSearchKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfSearchKeyPressed(evt);
            }
        });

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/form/icon/search.png"))); // NOI18N

        jLabel10.setText("Kode Barang");

        tfDBKodeBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDBKodeBarangActionPerformed(evt);
            }
        });
        tfDBKodeBarang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfDBKodeBarangKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfDBKodeBarangKeyPressed(evt);
            }
        });

        jLabel11.setText("Tanggal");

        jDateChooser1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jDateChooser1KeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jDateChooser1KeyPressed(evt);
            }
        });

        DBclear.setText("Clear");
        DBclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DBclearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnldatabarangLayout = new javax.swing.GroupLayout(pnldatabarang);
        pnldatabarang.setLayout(pnldatabarangLayout);
        pnldatabarangLayout.setHorizontalGroup(
            pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnldatabarangLayout.createSequentialGroup()
                .addGap(441, 441, 441)
                .addComponent(ldatabarang)
                .addGap(36, 36, 36)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnldatabarangLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(tfDBNamaBarang, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnldatabarangLayout.createSequentialGroup()
                                    .addGap(5, 5, 5)
                                    .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel10)
                                        .addComponent(jLabel11)
                                        .addComponent(tfDBKodeBarang, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(tfDBHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tfDBPcs, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnldatabarangLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel8))))
                    .addGroup(pnldatabarangLayout.createSequentialGroup()
                        .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(DBedit)
                            .addComponent(DBclear))
                        .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnldatabarangLayout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(DBhapus))
                            .addGroup(pnldatabarangLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(DBsimpan)))))
                .addGap(53, 53, 53)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(89, 89, 89))
        );

        pnldatabarangLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {DBclear, DBedit, DBhapus, DBsimpan});

        pnldatabarangLayout.setVerticalGroup(
            pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnldatabarangLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfDBKodeBarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addGap(5, 5, 5)
                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfDBNamaBarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfDBHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfDBPcs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DBsimpan)
                    .addComponent(DBclear))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DBhapus)
                    .addComponent(DBedit))
                .addGap(213, 213, 213))
            .addGroup(pnldatabarangLayout.createSequentialGroup()
                .addGroup(pnldatabarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnldatabarangLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(ldatabarang))
                    .addGroup(pnldatabarangLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel9))
                    .addGroup(pnldatabarangLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(tfSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.add(pnldatabarang, "card3");

        pnllaporantransaksi.setBackground(new java.awt.Color(204, 255, 204));

        javax.swing.GroupLayout pnllaporantransaksiLayout = new javax.swing.GroupLayout(pnllaporantransaksi);
        pnllaporantransaksi.setLayout(pnllaporantransaksiLayout);
        pnllaporantransaksiLayout.setHorizontalGroup(
            pnllaporantransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 865, Short.MAX_VALUE)
        );
        pnllaporantransaksiLayout.setVerticalGroup(
            pnllaporantransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 657, Short.MAX_VALUE)
        );

        jPanel3.add(pnllaporantransaksi, "card7");

        pnldatapelanggan.setBackground(new java.awt.Color(153, 255, 204));

        javax.swing.GroupLayout pnldatapelangganLayout = new javax.swing.GroupLayout(pnldatapelanggan);
        pnldatapelanggan.setLayout(pnldatapelangganLayout);
        pnldatapelangganLayout.setHorizontalGroup(
            pnldatapelangganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 865, Short.MAX_VALUE)
        );
        pnldatapelangganLayout.setVerticalGroup(
            pnldatapelangganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 657, Short.MAX_VALUE)
        );

        jPanel3.add(pnldatapelanggan, "card8");

        lbluserlogin.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        lbluserlogin.setForeground(new java.awt.Color(255, 153, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 869, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(lbluserlogin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Jam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Jam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbluserlogin))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDashboardActionPerformed
        // TODO add your handling code here:
//mengganti panel
pnldashboard.setVisible(true);
pnldatabarang.setVisible(false);
pnldatasupplier.setVisible(false);
pnlpembelianbarang.setVisible(false);
pnlpenjualanbarang.setVisible(false);
pnllaporantransaksi.setVisible(false);
pnldatapelanggan.setVisible(false);
//Warna tombol
jDashboard.setBackground(Color.white);
jDataBarang.setBackground(new Color(204,204,255));
jDataSupplier.setBackground(new Color(204,204,255));
jPembelianBarang.setBackground(new Color(204,204,255));
jTransaksi.setBackground(new Color(204,204,255));
jLaporanTransaksi.setBackground(new Color(204,204,255));
jDataPelanggan.setBackground(new Color(204,204,255));
jExit.setBackground(new Color(204,204,255));
//add panel baru
         
    }//GEN-LAST:event_jDashboardActionPerformed

    private void jPembelianBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPembelianBarangActionPerformed
        // TODO add your handling code here:
pnldashboard.setVisible(false);
pnldatabarang.setVisible(false);
pnldatasupplier.setVisible(false);
pnlpembelianbarang.setVisible(true);
pnlpenjualanbarang.setVisible(false);
pnllaporantransaksi.setVisible(false);
pnldatapelanggan.setVisible(false);

jDashboard.setBackground(new Color(204,204,255));
jDataBarang.setBackground(new Color(204,204,255));
jDataSupplier.setBackground(new Color(204,204,255));
jPembelianBarang.setBackground(Color.white);
jTransaksi.setBackground(new Color(204,204,255));
jLaporanTransaksi.setBackground(new Color(204,204,255));
jDataPelanggan.setBackground(new Color(204,204,255));
jExit.setBackground(new Color(204,204,255));
    }//GEN-LAST:event_jPembelianBarangActionPerformed

    private void jTransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTransaksiActionPerformed
        // TODO add your handling code here:
pnldashboard.setVisible(false);
pnldatabarang.setVisible(false);
pnldatasupplier.setVisible(false);
pnlpembelianbarang.setVisible(false);
pnlpenjualanbarang.setVisible(true);
pnllaporantransaksi.setVisible(false);
pnldatapelanggan.setVisible(false);

jDashboard.setBackground(new Color(204,204,255));
jDataBarang.setBackground(new Color(204,204,255));
jDataSupplier.setBackground(new Color(204,204,255));
jPembelianBarang.setBackground(new Color(204,204,255));
jTransaksi.setBackground(Color.white);
jLaporanTransaksi.setBackground(new Color(204,204,255));
jDataPelanggan.setBackground(new Color(204,204,255));
jExit.setBackground(new Color(204,204,255));
    }//GEN-LAST:event_jTransaksiActionPerformed

    private void jLaporanTransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLaporanTransaksiActionPerformed
        // TODO add your handling code here:
pnldashboard.setVisible(false);
pnldatabarang.setVisible(false);
pnldatasupplier.setVisible(false);
pnlpembelianbarang.setVisible(false);
pnlpenjualanbarang.setVisible(false);
pnllaporantransaksi.setVisible(true);
pnldatapelanggan.setVisible(false);        
        
        
jDashboard.setBackground(new Color(204,204,255));
jDataBarang.setBackground(new Color(204,204,255));
jDataSupplier.setBackground(new Color(204,204,255));
jPembelianBarang.setBackground(new Color(204,204,255));
jTransaksi.setBackground(new Color(204,204,255));
jLaporanTransaksi.setBackground(Color.white);
jDataPelanggan.setBackground(new Color(204,204,255));
jExit.setBackground(new Color(204,204,255));
    }//GEN-LAST:event_jLaporanTransaksiActionPerformed

    private void btentangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btentangActionPerformed
        // TODO add your handling code here:
        tentang t = new tentang();
                t.setVisible(true);
        
    }//GEN-LAST:event_btentangActionPerformed

    private void jDataBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDataBarangActionPerformed
        // TODO add your handling code here:
pnldashboard.setVisible(false);
pnldatabarang.setVisible(true);
pnldatasupplier.setVisible(false);
pnlpembelianbarang.setVisible(false);
pnlpenjualanbarang.setVisible(false);
pnllaporantransaksi.setVisible(false);
pnldatapelanggan.setVisible(false);

jDashboard.setBackground(new Color(204,204,255));
jDataBarang.setBackground(Color.white);
jDataSupplier.setBackground(new Color(204,204,255));
jPembelianBarang.setBackground(new Color(204,204,255));
jTransaksi.setBackground(new Color(204,204,255));
jLaporanTransaksi.setBackground(new Color(204,204,255));
jDataPelanggan.setBackground(new Color(204,204,255));
jExit.setBackground(new Color(204,204,255));
    }//GEN-LAST:event_jDataBarangActionPerformed

    private void jDataSupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDataSupplierActionPerformed
        // TODO add your handling code here:
pnldashboard.setVisible(false);
pnldatabarang.setVisible(false);
pnldatasupplier.setVisible(true);
pnlpembelianbarang.setVisible(false);
pnlpenjualanbarang.setVisible(false);
pnllaporantransaksi.setVisible(false);
pnldatapelanggan.setVisible(false);

jDashboard.setBackground(new Color(204,204,255));
jDataBarang.setBackground(new Color(204,204,255));
jDataSupplier.setBackground(Color.white);
jPembelianBarang.setBackground(new Color(204,204,255));
jTransaksi.setBackground(new Color(204,204,255));
jLaporanTransaksi.setBackground(new Color(204,204,255));
jDataPelanggan.setBackground(new Color(204,204,255));
jExit.setBackground(new Color(204,204,255));
    }//GEN-LAST:event_jDataSupplierActionPerformed

    private void tanggalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tanggalKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_tanggalKeyPressed

    private void kode_barang_otomatis(){
        try{
            Statement S = con.createStatement(); 
            String sql = "SELECT * FROM data_barang order by kodebarang desc";
            ResultSet R = S.executeQuery(sql);
            
           if(R.next()){
               String kode= R.getString("kodebarang").substring(1);
               String AN = "" + (Integer.parseInt(kode) + 1);
               String Nol = "";
               
               if(AN.length()== 1)
               {Nol = "00";}
               else if(AN.length()==2)
               {Nol = "0";}
               else if(AN.length()==3)
               {Nol = "";}
               
               tfDBKodeBarang.setText("KD-" + Nol + AN);
               
           }else{
               tfDBKodeBarang.setText("KD-001");
           }
           
           
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, e);
        }
    }
    
    private void DBsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DBsimpanActionPerformed
        // TODO add your handling code here:
        String tampilan = "dd-MM-yyyy";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tanggal = String.valueOf(fm.format(jDateChooser1.getDate()));
        try {
            String sql = "INSERT INTO data_barang VALUES ('"
                    +tfDBKodeBarang.getText()+"','"
                    +tanggal+"','"
                    +tfDBNamaBarang.getText()+"','"
                    +tfDBHarga.getText()+"','"
                    +tfDBPcs.getText()+"')";
            Statement statement = con.createStatement(); 
            statement.executeUpdate(sql);
            
          
           updateTableauto();
           JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_DBsimpanActionPerformed

    private void DBeditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DBeditActionPerformed
        // TODO add your handling code here:
        String tampilan = "dd-MM-yyyy";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tanggal = String.valueOf(fm.format(jDateChooser1.getDate()));
        
        String kode =tfDBKodeBarang.getText();
        String tgl =  tanggal;
        String namabarang = tfDBNamaBarang.getText();
        String harga = tfDBHarga.getText();
        String pcs = tfDBPcs.getText();
        
          try {
            String sql ="UPDATE data_barang SET tanggal = '"+tgl+"',namabarang = '"+namabarang+"',harga = '"+harga+"',pcs = '"+pcs+"' WHERE kodebarang = '"+kode+"'";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            updateTableauto();
            JOptionPane.showMessageDialog(null, "Data Berhasil DiUpdate");
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"+e.getMessage());
        }
      
           
      
       
    }//GEN-LAST:event_DBeditActionPerformed

    private void DBeditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DBeditMouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_DBeditMouseClicked

    private void TdatabarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TdatabarangMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)Tdatabarang.getModel(); 
         int index = Tdatabarang.getSelectedRow();
//         int baris = Tdatabarang.rowAtPoint(evt.getPoint());
         Date date;
       try {
           date = new SimpleDateFormat("dd-MM-yyyy").parse((String)model.getValueAt(index, 1));
           jDateChooser1.setDate(date);
       } catch (ParseException ex) {
           Logger.getLogger(tampilanAwal.class.getName()).log(Level.SEVERE, null, ex);
       }
         
        
         
         String kode = Tdatabarang.getValueAt(index, 0).toString();
         tfDBKodeBarang.setText(kode);
//         String tanggal = Tdatabarang.getValueAt(baris, 1).toString();
//         jDateChooser1.setDateFormatString(tanggal);
         
         String namabarang = Tdatabarang.getValueAt(index, 2).toString();
         tfDBNamaBarang.setText(namabarang);
         String harga = Tdatabarang.getValueAt(index, 3).toString();
         tfDBHarga.setText(harga);
         String pcs = Tdatabarang.getValueAt(index, 4).toString();
         tfDBPcs.setText(pcs);     
    }//GEN-LAST:event_TdatabarangMouseClicked

    private void DBhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DBhapusActionPerformed
        // TODO add your handling code here:
        try{
        String sql = "delete from data_barang where kodebarang='"+tfDBKodeBarang.getText() +"'";
         Statement statement = con.createStatement(); 
                    statement.executeUpdate(sql);
        java.sql.Connection conn=koneksi.koneksiDb();
                    java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                    pst.execute();
                    updateTableautoDS();
                    kosong();

        JOptionPane.showMessageDialog(null,"Data berhasil di hapus");

        }catch (Exception e){

        JOptionPane.showMessageDialog(null,"Proses hapus gagal/koneksi gagal..");

        System.out.println(e.getMessage());
 
}
 

    }//GEN-LAST:event_DBhapusActionPerformed

    private void tfSearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfSearchKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)
        {
        DefaultTableModel table = new DefaultTableModel();
        
        table.addColumn("Kode Barang");
        table.addColumn("Tanggal");
        table.addColumn("Nama Barang");
        table.addColumn("Harga");
        table.addColumn("Pcs");        
        try
        {    
            String sql = "SELECT * FROM data_barang WHERE kodebarang='"+tfSearch.getText()+"'";
            Statement S = koneksi.koneksiDb().createStatement();
            ResultSet R = S.executeQuery(sql);
            
            while(R.next())
            {
                table.addRow(new Object[]{
                    R.getString(1),
                    R.getString(2),
                    R.getString(3),
                    R.getString(4),
                    R.getString(5),
                        
                });
            }
            Tdatabarang.setModel(table);
        }
        catch(Exception e){
    
}
        }
    }//GEN-LAST:event_tfSearchKeyPressed

    private void tfSearchKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfSearchKeyTyped
        // TODO add your handling code here:
        if("".equals(tfSearch.getText())){
            listed();
        }
    }//GEN-LAST:event_tfSearchKeyTyped

    private void tfDBKodeBarangKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfDBKodeBarangKeyTyped
        // TODO add your handling code here:       
        char karakter = evt.getKeyChar();
if(!(((karakter >= '0') && (karakter <= '9') || (karakter == KeyEvent.VK_BACK_SPACE) || (karakter == KeyEvent.VK_DELETE)))){
    getToolkit().beep();
    evt.consume();
}
    }//GEN-LAST:event_tfDBKodeBarangKeyTyped

    private void tfDBHargaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfDBHargaKeyTyped
        // TODO add your handling code here:
        char karakter = evt.getKeyChar();
if(!(((karakter >= '0') && (karakter <= '9') || (karakter == KeyEvent.VK_BACK_SPACE) || (karakter == KeyEvent.VK_DELETE)))){
    getToolkit().beep();
    evt.consume();
}
    }//GEN-LAST:event_tfDBHargaKeyTyped

    private void tfDBPcsKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfDBPcsKeyTyped
        // TODO add your handling code here:
        char karakter = evt.getKeyChar();
if(!(((karakter >= '0') && (karakter <= '9') || (karakter == KeyEvent.VK_BACK_SPACE) || (karakter == KeyEvent.VK_DELETE)))){
    getToolkit().beep();
    evt.consume();
}
    }//GEN-LAST:event_tfDBPcsKeyTyped

    private void jDateChooser1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jDateChooser1KeyTyped
        // TODO add your handling code here:
        char karakter = evt.getKeyChar();
if(!(((karakter >= '0') && (karakter <= '9') || (karakter == KeyEvent.VK_BACK_SPACE) || (karakter == KeyEvent.VK_DELETE)))){
    getToolkit().beep();
    evt.consume();
}
    }//GEN-LAST:event_jDateChooser1KeyTyped

    private void DBclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DBclearActionPerformed
        // TODO add your handling code here:
        kosong();
    }//GEN-LAST:event_DBclearActionPerformed

    private void tfSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfSearchActionPerformed

    private void tfDBKodeBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDBKodeBarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfDBKodeBarangActionPerformed

    private void tfDBKodeBarangKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfDBKodeBarangKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_tfDBKodeBarangKeyPressed

    private void jDateChooser1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jDateChooser1KeyPressed
        // TODO add your handling code here:
        
    
    }//GEN-LAST:event_jDateChooser1KeyPressed

    private void belalamatsupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belalamatsupplierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_belalamatsupplierActionPerformed

    private void belnamasupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belnamasupplierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_belnamasupplierActionPerformed

    private void belkontakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belkontakActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_belkontakActionPerformed

    private void belkueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belkueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_belkueActionPerformed

    private void belhargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belhargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_belhargaActionPerformed

    private void belmetodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belmetodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_belmetodeActionPerformed

    private void beldetailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beldetailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_beldetailActionPerformed

    private void belsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_belsearchActionPerformed

    private void PBsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PBsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PBsearchActionPerformed

    private void DSnamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DSnamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DSnamaActionPerformed

    private void PBclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PBclearActionPerformed
        // TODO add your handling code here:
        PBkosong();
    }//GEN-LAST:event_PBclearActionPerformed

//   public void dataFromDataBaseToComboBox(){
//       
//        try {
//            String query = "SELECT * FROM data_barang";
//            Statement st = con.createStatement();
//            ResultSet rs = st.executeQuery(query);
//            
//            while (rs.next()) {                
//                jComboBox1.addItem(rs.getString("nama"));
//            }
//            
//            rs.last();
//            int jumlahdata = rs.getRow();
//            rs.first();
//            
//        } catch (SQLException e) {
//        }
//   }
    
    private void PBsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PBsimpanActionPerformed
        // TODO add your handling code here:
          String tampilan = "dd-MM-yyyy";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tanggal = String.valueOf(fm.format(PBtanggaltransaksi.getDate()));
        try {
            String sql = "INSERT INTO penjualan_barang VALUES ('"
                   
                    +tanggal+"','"
                   
                    +PBjumlahbeli.getText()+"','"
                    +PBhargasatuan.getText()+"','"                                 
                    +PBtotalbayar.getText()+"')";
            Statement statement = con.createStatement(); 
            statement.executeUpdate(sql);

           updateTableautoPB();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_PBsimpanActionPerformed

    private void PBeditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PBeditMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_PBeditMouseClicked

    private void PBeditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PBeditActionPerformed
        // TODO add your handling code here:
           String tampilan = "dd-MM-yyyy";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tanggal = String.valueOf(fm.format(PBtanggaltransaksi.getDate()));
        
    
        String tgl =  tanggal;
       
        String jumlahbeli = PBjumlahbeli.getText();
        String hargasatu = PBhargasatuan.getText();
        
        String total = PBtotalbayar.getText();
       
        
          try {
            String sql ="UPDATE penjualan_barang SET namapelanggan = '"+"tanggal = '"+tgl+"'"
//                    + ",namabarang = '"+namakue+"',"
//                    + "pcs = '"+jumlahbeli+"',harga = '"+hargasatu+"',"
//                    + "metodepembayaran = '"+metode+"',totalbayar = '"
//                    +total+"' WHERE kodebarang='"+kode+"'"
                    ;
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            updateTableautoPB();
            JOptionPane.showMessageDialog(null, "Data Berhasil DiUpdate");
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"+e.getMessage());
        }
    }//GEN-LAST:event_PBeditActionPerformed

    private void PBhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PBhapusActionPerformed
        // TODO add your handling code here:
        try{
        String sql = "delete from penjualan_barang where kodebarang='"
//                +CBkodebarang.selectedItem() +"'"
                ;
         Statement statement = con.createStatement(); 
                    statement.executeUpdate(sql);
        java.sql.Connection conn=koneksi.koneksiDb();
                    java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                    pst.execute();
                    updateTableautoPB();
                    PBkosong();

        JOptionPane.showMessageDialog(null,"Data berhasil di hapus");

        }catch (Exception e){

        JOptionPane.showMessageDialog(null,"Proses hapus gagal/koneksi gagal..");

        System.out.println(e.getMessage());
 
}
        
    }//GEN-LAST:event_PBhapusActionPerformed

    private void DSSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DSSimpanActionPerformed
        // TODO add your handling code here:
        
        String tampilan = "dd-MM-yyyy";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tanggal = String.valueOf(fm.format(DStanggal.getDate()));
        int id = 0;
        try {
            String sql = "INSERT INTO data_supplier(nama,tanggalawal,alamat,no_telepon,email,produk,riwayat_pembelian,pembayaran) VALUES ('"
                    
                    +DSnama.getText()+"','"
                    +tanggal+"','"
                    +DSalamat.getText()+"','"
                    +DSnotlpn.getText()+"','"
                    +DSemail.getText()+"','"
                    +DSProduk.getText()+"','"
                    +DSRiwayat.getText()+"','"
                    +DSPembayaran.getText()+"')";
            Statement statement = con.createStatement(); 
            statement.executeUpdate(sql);

            updateTableautoDS();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_DSSimpanActionPerformed

    private void DSclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DSclearActionPerformed
        // TODO add your handling code here:
        DSkosong();
    }//GEN-LAST:event_DSclearActionPerformed

    private void DSHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DSHapusActionPerformed
 try{
        String sql = "delete from data_supplier where id=`id`";
         Statement statement = con.createStatement(); 
                    statement.executeUpdate(sql);
        java.sql.Connection conn=koneksi.koneksiDb();
                    java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                    pst.execute();
                    updateTableautoDS();
                    DSkosong();

        JOptionPane.showMessageDialog(null,"Data berhasil di hapus");

        }catch (Exception e){

        JOptionPane.showMessageDialog(null,"Proses hapus gagal/koneksi gagal..");

        System.out.println(e.getMessage());
 
}        // TODO add your handling code here:
    }//GEN-LAST:event_DSHapusActionPerformed

    private void DSEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DSEditActionPerformed
        // TODO add your handling code here:
         String tampilan = "dd-MM-yyyy";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tanggal = String.valueOf(fm.format(DStanggal.getDate()));
        
        String nama =DSnama.getText();
        String tgl =  tanggal;
        String alamat = DSalamat.getText();
        String notlpn = DSnotlpn.getText();
        String email = DSemail.getText();
        String produk = DSProduk.getText();
        String riwayat = DSRiwayat.getText();
        String pembayaran = DSPembayaran.getText();
        
          try {
            String sql ="UPDATE data_supplier SET nama = '"+nama+"',tanggalawal = '"+tgl+"',alamat = '"+alamat+"',no_telepon = '"+notlpn+"',email = '"+email+"',produk = '"+produk+"',riwayat_pembelian = '"+riwayat+"',pembayaran = '"+pembayaran+"' WHERE id=`id`";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            updateTableautoDS();
            JOptionPane.showMessageDialog(null, "Data Berhasil DiUpdate");
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"+e.getMessage());
        }
    }//GEN-LAST:event_DSEditActionPerformed

    private void DStableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DStableMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)DStable.getModel(); 
         int index = DStable.getSelectedRow();
//         int baris = Tdatabarang.rowAtPoint(evt.getPoint());
         Date date;
       try {
           date = new SimpleDateFormat("dd-MM-yyyy").parse((String)model.getValueAt(index, 2));
           DStanggal.setDate(date);
       } catch (ParseException ex) {
           Logger.getLogger(tampilanAwal.class.getName()).log(Level.SEVERE, null, ex);
       }
         
         String nama = DStable.getValueAt(index, 1).toString();
         DSnama.setText(nama);
         String alamat = DStable.getValueAt(index, 3).toString();
         DSalamat.setText(alamat);
         String no = DStable.getValueAt(index, 4).toString();
         DSnotlpn.setText(no);
         String email = DStable.getValueAt(index, 5).toString();
         DSemail.setText(email);
         String produk = DStable.getValueAt(index, 6).toString();
         DSProduk.setText(produk);
         String riwayat = DStable.getValueAt(index, 7).toString();
         DSRiwayat.setText(riwayat);
         String pembayaran = DStable.getValueAt(index, 8).toString();
         DSPembayaran.setText(pembayaran);
    }//GEN-LAST:event_DStableMouseClicked

    private void tfDSSearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfDSSearchKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)
        {
        DefaultTableModel table = new DefaultTableModel();
        table.addColumn("Id");
        table.addColumn("Nama");
        table.addColumn("Tgl Supply");
        table.addColumn("Alamat");
        table.addColumn("No Tlp");
        table.addColumn("Email");
        table.addColumn("Produk");
        table.addColumn("Riwayat Pembelian");
        table.addColumn("Pembayaran");       
        try
        {    
            String sql = "SELECT * FROM data_supplier WHERE nama='"+tfDSSearch.getText()+"'";
            Statement S = koneksi.koneksiDb().createStatement();
            ResultSet R = S.executeQuery(sql);
            
            while(R.next())
            {
                table.addRow(new Object[]{
                    R.getString(1),
                    R.getString(2),
                    R.getString(3),
                    R.getString(4),
                    R.getString(5),
                    R.getString(6),  
                    R.getString(7),
                    R.getString(8),
                    R.getString(9),
                });
            }
            DStable.setModel(table);
        }
        catch(Exception e){
    
}
        }
    }//GEN-LAST:event_tfDSSearchKeyPressed

    private void tfDSSearchKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfDSSearchKeyTyped
        // TODO add your handling code here:
         if("".equals(tfDSSearch.getText())){
            listedDS();
        }
    }//GEN-LAST:event_tfDSSearchKeyTyped

    private void PBsearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PBsearchKeyPressed
        // TODO add your handling code here:
         if(evt.getKeyCode()==KeyEvent.VK_ENTER)
        {
        DefaultTableModel table = new DefaultTableModel();
        
        table.addColumn("Kode");
        table.addColumn("Nama");
        table.addColumn("Tgl");
        table.addColumn("Nama Kue");
        table.addColumn("Jumlah");   
        table.addColumn("Harga"); 
        table.addColumn("Metode Pembayaran"); 
        table.addColumn("Total Bayar"); 
        try
        {    
            String sql = "SELECT * FROM penjualan_barang WHERE kodebarang='"+PBsearch.getText()+"'";
            Statement S = koneksi.koneksiDb().createStatement();
            ResultSet R = S.executeQuery(sql);
            
            while(R.next())
            {
                table.addRow(new Object[]{
                    R.getString(1),
                    R.getString(2),
                    R.getString(3),
                    R.getString(4),
                    R.getString(5),
                    R.getString(6),
                    R.getString(7),
                    R.getString(8),
                        
                });
            }
            PBTable.setModel(table);
        }
        catch(Exception e){
    
}
        }
    }//GEN-LAST:event_PBsearchKeyPressed

    private void PBTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PBTableMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)PBTable.getModel(); 
         int index = PBTable.getSelectedRow();
//         int baris = Tdatabarang.rowAtPoint(evt.getPoint());
         Date date;
       try {
           date = new SimpleDateFormat("dd-MM-yyyy").parse((String)model.getValueAt(index, 2));
           PBtanggaltransaksi.setDate(date);
       } catch (ParseException ex) {
           Logger.getLogger(tampilanAwal.class.getName()).log(Level.SEVERE, null, ex);
       }
         
//         String kode = PBTable.getValueAt(index, 0).toString();
//         PBkodebarang.setText(kode);
         String pelanggan = PBTable.getValueAt(index, 1).toString();
//         PBnamapelanggan.setText(pelanggan);
//         String namakue = PBTable.getValueAt(index, 3).toString();
//         PBnamakue.setText(namakue);
         String jumlahbeli = PBTable.getValueAt(index, 4).toString();
         PBjumlahbeli.setText(jumlahbeli);
         String hargasatuan = PBTable.getValueAt(index, 5).toString();
         PBhargasatuan.setText(hargasatuan);
//         String metodebayar = PBTable.getValueAt(index, 6).toString();
//         PBmetodepembayaran.setText(metodebayar);
         String totalbayar = PBTable.getValueAt(index, 7).toString();
         PBtotalbayar.setText(totalbayar);
    }//GEN-LAST:event_PBTableMouseClicked

    private void belsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belsimpanActionPerformed
        // TODO add your handling code here:
        String tampilan = "dd-MM-yyyy";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tanggal = String.valueOf(fm.format(beltanggal.getDate()));
        try {
            String sql = "INSERT INTO pembelian_barang(tanggal,nama,alamat,nomor,namabarang,harga,metode,pcs) VALUES ('"   
                    
                    +tanggal+"','"
                    +belnamasupplier.getText()+"','"
                    +belalamatsupplier.getText()+"','"
                    +belkontak.getText()+"','"
                    +belkue.getText()+"','"
                    +belharga.getText()+"','"
                    +belmetode.getText()+"','"
                    +beldetail.getText()+"')";
            Statement statement = con.createStatement(); 
            statement.executeUpdate(sql);

           updateTableautobel();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_belsimpanActionPerformed

    private void belclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belclearActionPerformed
        // TODO add your handling code here:
        belkosong();
    }//GEN-LAST:event_belclearActionPerformed

    private void beleditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beleditActionPerformed
        // TODO add your handling code here:
         String tampilan = "dd-MM-yyyy";
        SimpleDateFormat fm = new SimpleDateFormat(tampilan);
        String tanggal = String.valueOf(fm.format(beltanggal.getDate()));
        
        String tgl = tanggal;
        String nama =belnamasupplier.getText();
        String alamat = belalamatsupplier.getText();
        String nomor = belkontak.getText();
        String kue = belkue.getText();
        String harga = belharga.getText();
        String metode = belmetode.getText();
        String detail = beldetail.getText();
          try {
            String sql ="UPDATE pembelian_barang SET tanggal = '"+tgl+"',nama = '"+nama+"',alamat = '"+alamat+"',nomor = '"+nomor+"',namabarang = '"+kue+"',harga = '"+harga+"',metode = '"+metode+"',pcs = '"+detail+"' WHERE id =`id` ";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            updateTableautobel();
            JOptionPane.showMessageDialog(null, "Data Berhasil DiUpdate");
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"+e.getMessage());
        }
    }//GEN-LAST:event_beleditActionPerformed

    private void belhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belhapusActionPerformed
        // TODO add your handling code here:
        try{
        String sql = "delete from pembelian_barang where nama='"+belnamasupplier.getText() +"'";
         Statement statement = con.createStatement(); 
                    statement.executeUpdate(sql);
        java.sql.Connection conn=koneksi.koneksiDb();
                    java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                    pst.execute();
                    updateTableautobel();
                    belkosong();

        JOptionPane.showMessageDialog(null,"Data berhasil di hapus");

        }catch (Exception e){

        JOptionPane.showMessageDialog(null,"Proses hapus gagal/koneksi gagal..");

        System.out.println(e.getMessage());
 
}
    }//GEN-LAST:event_belhapusActionPerformed

    private void belsearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_belsearchKeyPressed
        // TODO add your handling code here:
         if(evt.getKeyCode()==KeyEvent.VK_ENTER)
        {
         DefaultTableModel table = new DefaultTableModel();
        table.addColumn("Id");
        table.addColumn("Tgl Supply");
        table.addColumn("Nama Supplier");
        table.addColumn("Alamat");
        table.addColumn("No Kontak");
        table.addColumn("Kue");
        table.addColumn("Harga");
        table.addColumn("Metode");
        table.addColumn("Pengiriman");       
        try
        {    
            String sql = "SELECT * FROM pembelian_barang WHERE nama='"+belsearch.getText()+"'";
            Statement S = koneksi.koneksiDb().createStatement();
            ResultSet R = S.executeQuery(sql);
            
            while(R.next())
            {
                table.addRow(new Object[]{
                    R.getString(1),
                    R.getString(2),
                    R.getString(3),
                    R.getString(4),
                    R.getString(5),
                    R.getString(6),  
                    R.getString(7),
                    R.getString(8),
                    R.getString(9),
                });
            }
            beltable.setModel(table);
        }
        catch(Exception e){
    
}
        }
    }//GEN-LAST:event_belsearchKeyPressed

    private void belsearchKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_belsearchKeyTyped
        // TODO add your handling code here:
        if("".equals(belsearch.getText())){
            listedbel();
        }
    }//GEN-LAST:event_belsearchKeyTyped

    private void beltableKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_beltableKeyPressed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_beltableKeyPressed

    private void beltableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_beltableMouseClicked
        // TODO add your handling code here:
          DefaultTableModel model = (DefaultTableModel)beltable.getModel(); 
         int index = beltable.getSelectedRow();
//         int baris = Tdatabarang.rowAtPoint(evt.getPoint());
         Date date;
       try {
           date = new SimpleDateFormat("dd-MM-yyyy").parse((String)model.getValueAt(index, 1));
           beltanggal.setDate(date);
       } catch (ParseException ex) {
           Logger.getLogger(tampilanAwal.class.getName()).log(Level.SEVERE, null, ex);
       }
         
         String nama = beltable.getValueAt(index, 2).toString();
         belnamasupplier.setText(nama);
         String alamat = beltable.getValueAt(index, 3).toString();
         belalamatsupplier.setText(alamat);
         String no = beltable.getValueAt(index, 4).toString();
         belkontak.setText(no);
         String kue = beltable.getValueAt(index, 5).toString();
         belkue.setText(kue);
         String harga = beltable.getValueAt(index, 6).toString();
         belharga.setText(harga);
         String metode = beltable.getValueAt(index, 7).toString();
         belmetode.setText(metode);
         String detail = beltable.getValueAt(index, 8).toString();
         beldetail.setText(detail);
         
//         belhapus.setEnabled(true);
//         beledit.setEnabled(true);
    }//GEN-LAST:event_beltableMouseClicked

    
    
    private void jExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jExitActionPerformed
        // TODO add your handling code here:
jDashboard.setBackground(new Color(204,204,255));
jDataBarang.setBackground(new Color(204,204,255));
jDataSupplier.setBackground(new Color(204,204,255));
jPembelianBarang.setBackground(new Color(204,204,255));
jTransaksi.setBackground(new Color(204,204,255));
jLaporanTransaksi.setBackground(new Color(204,204,255));
jDataPelanggan.setBackground(new Color(204,204,255));
jExit.setBackground(Color.white);

        exit e = new exit();
        e.setVisible(true);
    }//GEN-LAST:event_jExitActionPerformed

    private void jDataPelangganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDataPelangganActionPerformed
        // TODO add your handling code here:
        pnldashboard.setVisible(false);
pnldatabarang.setVisible(false);
pnldatasupplier.setVisible(false);
pnlpembelianbarang.setVisible(false);
pnlpenjualanbarang.setVisible(false);
pnllaporantransaksi.setVisible(false);
pnldatapelanggan.setVisible(true);

jDashboard.setBackground(new Color(204,204,255));
jDataBarang.setBackground(new Color(204,204,255));
jDataSupplier.setBackground(new Color(204,204,255));
jPembelianBarang.setBackground(new Color(204,204,255));
jTransaksi.setBackground(new Color(204,204,255));
jLaporanTransaksi.setBackground(new Color(204,204,255));
jDataPelanggan.setBackground(Color.white);
jExit.setBackground(new Color(204,204,255));
    }//GEN-LAST:event_jDataPelangganActionPerformed

    private void PBhargasatuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PBhargasatuanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PBhargasatuanActionPerformed

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tampilanAwal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tampilanAwal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tampilanAwal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tampilanAwal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new tampilanAwal().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(tampilanAwal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBkodebarang;
    private javax.swing.JComboBox<String> CBmetodepembayaran;
    private javax.swing.JButton DBclear;
    private javax.swing.JButton DBedit;
    private javax.swing.JButton DBhapus;
    private javax.swing.JButton DBsimpan;
    private javax.swing.JButton DSEdit;
    private javax.swing.JButton DSHapus;
    private javax.swing.JTextField DSPembayaran;
    private javax.swing.JTextField DSProduk;
    private javax.swing.JTextField DSRiwayat;
    private javax.swing.JButton DSSimpan;
    private javax.swing.JTextField DSalamat;
    private javax.swing.JButton DSclear;
    private javax.swing.JTextField DSemail;
    private javax.swing.JTextField DSnama;
    private javax.swing.JTextField DSnotlpn;
    private javax.swing.JTable DStable;
    private com.toedter.calendar.JDateChooser DStanggal;
    private javax.swing.JPanel Jam;
    private javax.swing.JTable PBTable;
    private javax.swing.JButton PBclear;
    private javax.swing.JButton PBedit;
    private javax.swing.JButton PBhapus;
    private javax.swing.JTextField PBhargasatuan;
    private javax.swing.JTextField PBjumlahbeli;
    private javax.swing.JTextField PBkembalian;
    private javax.swing.JTextField PBsearch;
    private javax.swing.JButton PBsimpan;
    private com.toedter.calendar.JDateChooser PBtanggaltransaksi;
    private javax.swing.JTextField PBtotalbayar;
    private javax.swing.JTable Tdatabarang;
    private javax.swing.JTextField belalamatsupplier;
    private javax.swing.JButton belclear;
    private javax.swing.JTextField beldetail;
    private javax.swing.JButton beledit;
    private javax.swing.JButton belhapus;
    private javax.swing.JTextField belharga;
    private javax.swing.JTextField belkontak;
    private javax.swing.JTextField belkue;
    private javax.swing.JTextField belmetode;
    private javax.swing.JTextField belnamasupplier;
    private javax.swing.JTextField belsearch;
    private javax.swing.JButton belsimpan;
    private javax.swing.JTable beltable;
    private com.toedter.calendar.JDateChooser beltanggal;
    private javax.swing.JButton btentang;
    private javax.swing.JButton jDashboard;
    private javax.swing.JButton jDataBarang;
    private javax.swing.JButton jDataPelanggan;
    private javax.swing.JButton jDataSupplier;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JButton jExit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton jLaporanTransaksi;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JButton jPembelianBarang;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton jTransaksi;
    private javax.swing.JLabel lbluserlogin;
    private javax.swing.JLabel ldatabarang;
    private javax.swing.JLabel ljam;
    private javax.swing.JLabel pnldashboard;
    private javax.swing.JPanel pnldatabarang;
    private javax.swing.JPanel pnldatapelanggan;
    private javax.swing.JPanel pnldatasupplier;
    private javax.swing.JPanel pnllaporantransaksi;
    private javax.swing.JPanel pnlpembelianbarang;
    private javax.swing.JPanel pnlpenjualanbarang;
    private javax.swing.JLabel tanggal;
    private javax.swing.JTextField tfDBHarga;
    private javax.swing.JTextField tfDBKodeBarang;
    private javax.swing.JTextField tfDBNamaBarang;
    private javax.swing.JTextField tfDBPcs;
    private javax.swing.JTextField tfDSSearch;
    private javax.swing.JTextField tfSearch;
    // End of variables declaration//GEN-END:variables
}
